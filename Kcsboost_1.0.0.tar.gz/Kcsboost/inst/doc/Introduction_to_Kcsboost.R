## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----load_data----------------------------------------------------------------
library(Kcsboost)

## loading data 
data(creditcard)

## Creating a train set and test set that keep the same proportions of class imbalance
i0 <- which(creditcard$Class == 0)
i1 <- which(creditcard$Class == 1)

set.seed(2020)
i0_train <- sample(i0, size = 0.7 * length(i0))
i1_train <- sample(i1, size = 0.7 * length(i1))

train <- creditcard[ c(i0_train, i1_train), ]
test  <- creditcard[-c(i0_train, i1_train), ]

## Creating the cost matrix
cost_matrix_train <- cost_matrix_test <- matrix(c(25, 100, 75, 2), ncol = 2, byrow = TRUE)

## ----model--------------------------------------------------------------------
K2csb<- K2csboost(formula               = Class ~ . - 1,
                   train                 = train,
                   test                  = test,
                   cost_matrix_train     = cost_matrix_train,
                   cost_matrix_test      = cost_matrix_test,
                   nrounds               = 300,
                   early_stopping_rounds = 20,
                   verbose               = 1,
                   print_every_n         = 1)


## ----summary------------------------------------------------------------------
summary(K2csb)


## ----plot---------------------------------------------------------------------
plot(K2csb, legend_position = "right")

## ----predict------------------------------------------------------------------
pred <- predict(K2csb, newdata = test)

# Confusion matrix :
# library(caret)
# confusionMatrix(factor(as.numeric(pred>0.5)),factor(test$Class))


